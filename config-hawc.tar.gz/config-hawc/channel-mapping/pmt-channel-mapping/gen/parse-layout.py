from xml.dom import minidom


pmtLocationToSwChannel = {}
swChannelToPMTLocation = {}

for i in range(0,1):

    xmldoc = minidom.parse('HAWCRealSurvey.xml')

    tanklist = xmldoc.getElementsByTagName('tank') 

    columns = open("ChannelMapping.columns","w")
    print >> columns,"ChannelMappingVersion TDCChannelNumber SBC GeoID channelName SWChannelNumber"
    columns.close()
    #outfile = open("PMTLayout.table","w")


    for tank in tanklist:
        chanlist = tank.getElementsByTagName("channel")

        x = float(tank.getElementsByTagName("x")[0].firstChild.data)
        y = float(tank.getElementsByTagName("y")[0].firstChild.data)
        z = float(tank.getElementsByTagName("z")[0].firstChild.data)


        for chan in chanlist:
            name = chan.getElementsByTagName("name")[0].firstChild.data
            id = chan.attributes["id"].value

            dx = float(chan.getElementsByTagName("x")[0].firstChild.data)
            dy = float(chan.getElementsByTagName("y")[0].firstChild.data)
            dz = float(chan.getElementsByTagName("z")[0].firstChild.data)

            pmtLocationToSwChannel[name.rstrip().lstrip()] = id
            swChannelToPMTLocation[id] = name.rstrip().lstrip()


xmldoc = minidom.parse("HAWCRealTDCChannelMap.xml")

periodlist = xmldoc.getElementsByTagName("period")


version = 1

outfile = open("ChannelMapping.table","w")

for period in periodlist:
    begin = period.getElementsByTagName("begin")[0].firstChild.data
    end = period.getElementsByTagName("end")[0].firstChild.data

    periodDebugFile = open("period-%s-%s.dat"%(begin.rstrip().lstrip(),end.rstrip().lstrip()),"w")

    channels = period.getElementsByTagName("tdcChannel")

    print begin,end

    for chan in channels:
        id = None
        sbc = None
        geo = None
        gtc = None
        channelName = None

        if chan.attributes.has_key("id"):
            id = chan.attributes["id"].value

        if chan.attributes.has_key("sbc"):
            sbc = chan.attributes["sbc"].value

        if chan.attributes.has_key("geo"):
            geo = chan.attributes["geo"].value

        if chan.attributes.has_key("gtc"):
            gtc = chan.attributes["gtc"].value

        if chan.attributes.has_key("channelName"):
            channelName = chan.attributes["channelName"].value

        if channelName != None and geo != None and sbc != None:

            swChannel = None
            if pmtLocationToSwChannel.has_key(channelName):
                swChannel = pmtLocationToSwChannel[channelName]

            print >>outfile,id,sbc,geo,channelName,swChannel
            print >>periodDebugFile,id,sbc,geo,channelName,swChannel
    version = version + 1







