for i in range(0,32):
  print 2,2,"%2d %2d"%(i,i)
