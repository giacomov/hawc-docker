#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

from hawc import hawcnest, data_structures
from hawc.hawcnest import HAWCUnits as HAWCUnits
from hawc.data_structures import *

from hawc import detector_service as detector_service

from HAWCNest import HAWCNest

cm = HAWCUnits.cm
meter = HAWCUnits.meter

import os
import numpy as np
from optparse import OptionParser

scale=1.5
flaten = False # Ugly hack to flatten the detector, don't use me !

def get_detector_xycoords(dsname, opts, verbose=False):
    """ Get the x-y coordinates of all tanks and channels in a detector.

        @param dsname: string name of the detector service instance
    """
    # Access registered detector service by name, in the usual AERIE style
    ds = detector_service.GetService(dsname)
    detector = ds.GetDetector(TimeStamp(opts.gpssec))

    # Iterate over channels and print out the tanks and channels in a list
    lastTank = 0
    (tX, tY, tZ) = (0., 0., 0.)

    xCh = []
    yCh = []
    zCh = []

    xT = []
    yT = []

    xCent = detector.get_array_center_x()
    yCent = detector.get_array_center_y()
    zCent = detector.get_array_center_z()
    print xCent,yCent,zCent

    if verbose:
        print "#  GId  ChId  TkId     X       x [cm]      y [cm]      z [cm]"
    for channel in detector.channels():
        # Next tank
        if lastTank != channel.tank_id:
            lastTank = channel.tank_id
            tank = detector.get_tank(lastTank)
            p = tank.position
            (tX, tY, tZ) = (p.x/cm, p.y/cm, p.z/cm)
            xT.append(p.x / meter)
            yT.append(p.y / meter)

            # Print info if verbose flag is on
            if verbose:
                chInfo = "%6d%6d%6d%6d" % (tank.tank_id, -1, -1, 1)
                pInfo = "%12.2f%12.2f%12.2f" % (tX, tY, tZ)
                print "%s%s" % (chInfo, pInfo)

        if flaten:
            # Skip E12 tank
            if channel.channel_id in range(9,37): # 499
                continue

        # Next channel
        p = channel.position
        (cX, cY, cZ) = (p.x/cm, p.y/cm, p.z/cm)
        xCh.append(p.x / meter)
        yCh.append(p.y / meter)
        #zCh.append(p.z / cm + p.y / meter / 10)
        zz = p.z / cm
        if flaten:
            # flatening
            zz += p.y / meter /10 - p.x / meter *4./165 -72
            # moving C down
            # if channel.tank_channel_id == 3:
            #     zz -= 2.5
        zCh.append(zz)

        # Print info if verbose flag is on
        if verbose:
            chInfo = "%6d%6d%6d%6d" % (channel.channel_id, channel.tank_id, \
                                       channel.tank_channel_id, 1)
            pInfo = "%12.2f%12.2f%12.2f" % (cX - tX, cY - tY, cZ - tZ)
            vInfo = "%12.2f" % (cZ)
            print "%s%s%s" % (chInfo, pInfo, vInfo)
            if flaten:
                if(p.z / cm + p.y / meter /10 - p.x / meter *4./165>76.):
                    print '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'

    return xT, yT, xCh, yCh, zCh, xCent, yCent

def calc_xy_range(x, y):
    """ Given a list of xy coordinates, calculate x and y min and max ranges so
        that the detector plot can be made with a square aspect ratio.

        @param x: A list of detector component x-coordinates
        @param y: A list of detector component y-coordinates
    """
    # Let's assume everything is in meters.  Add a 10-meter border
    xMin = min(x) - 10.
    xMax = max(x) + 10.
    dx = abs(xMax - xMin)

    yMin = min(y) - 10.
    yMax = max(y) + 10.
    dy = abs(yMax - yMin)

    # Adjust the range to keep the aspect ratio square
    if dx > dy:
        yMin = yMin - 0.5*(dx - dy)
        yMax = yMax + 0.5*(dx - dy)
    else:
        xMin = xMin - 0.5*(dy - dx)
        xMax = xMax + 0.5*(dy - dx)

    return xMin, xMax, yMin, yMax

def draw_detector(xT, yT, xCh, yCh, zCh, xCent, yCent, opts):
    """ Draw the detector tanks and channels.

        @param xT: list of tank x-coordinates
        @param yT: list of tank y-coordinates
        @param xCh: list of channel x-coordinates
        @param yCh: list of channel y-coordinates
    """
    # Try to plot the coordinates; catch exceptions for users w/o matplotlib
    try:
        import matplotlib.pyplot as plt

        fig = plt.figure(figsize=(scale*7.5, scale*6), dpi=100)
        ax = fig.add_subplot(1,1,1)

        # First plot the tanks
        for i in range(0, len(xT)):
            c = plt.Circle((xT[i], yT[i]), radius=3.65,
                           fc="none", ec="#aaaaaa")
            ax.add_patch(c)

        # Then plot the channels
        xx, yy, zz = zip(*[[x,y,z] for x,y,z in zip(xCh,yCh,zCh) if z is not None])
        zmin = min(zz)
        zmax = max(zz)
        print 'Z range:', zmin, zmax
        s = ax.scatter(xx, yy, c=zz, s=20, linewidth=0.3) #, vmin=zmin, vmax=zmax)
        ax.set_xlabel("x [meter]")
        ax.set_ylabel("y [meter]")
        cb = fig.colorbar(s)
        cb.set_label("z [cm]")

        if opts.gridxy:
            ax.xaxis.grid()
            ax.yaxis.grid()

        ax.set_title("PMT heights for GPSSec %d" %opts.gpssec)

        xMin, xMax, yMin, yMax = calc_xy_range(xCh, yCh)
        xL = np.abs(xMax - xMin)
        yL = np.abs(yMax - yMin)
        if xL > yL:
            yMin -= 0.5*(xL-yL)
            yMax += 0.5*(xL-yL)
        else:
            xMin -= 0.5*(yL-xL)
            xMax += 0.5*(yL-xL)

        plt.plot([xCent],[yCent],"r*")
        plt.xlim([xMin, xMax])
        plt.ylim([yMin, yMax])
        plt.subplots_adjust(left=0.15, right=0.95)

        if opts.output:
            plt.savefig(opts.output)

        if not opts.nodisplay:
            plt.show()

    except ImportError, e:
        print "\nSorry, couldn't plot the detector: %s" % e

def main():
    """ Main function: execute the program here.
    """

    # Set up the command-line parser
    usage = "%prog [options]"
    parser = OptionParser(usage)
    parser.add_option("-s", "--gpssec", dest="gpssec", default=2000000000,
                      type="int", help="GPS second to get the detector")
    parser.add_option("-g", "--gridxy", dest="gridxy", default=False,
                      action="store_true",
                      help="Draw xy gridlines in the plot")
    parser.add_option("-o", "--output", dest="output", default=None,
                      help="Output plot to image file (e.g., image.png)")
    parser.add_option("-v", "--verbose", dest="verbose", default=False,
                      action="store_true",
                      help="Print detector coordinates as they are accessed")
    parser.add_option("--nodisplay", dest="nodisplay", default=False,
                      action="store_true",
                      help="No display")
    opts, args = parser.parse_args()
    if len(args) > 0:
        parser.error("Program takes no arguments; only options.")

    # Set up the HAWCNest framework and the detector service
    nest = HAWCNest()

    nest.Service("ConfigDirDetectorService", "detService",
        configDir=os.environ["CONFIG_HAWC"]);

    nest.Configure()
    nest.Finish()

    # Access pieces of the Detector and try to draw it
    xT, yT, xCh, yCh, zCh, xCent, yCent = get_detector_xycoords("detService", opts, verbose=opts.verbose)
    draw_detector(xT, yT, xCh, yCh, zCh, xCent, yCent, opts)


if __name__ == "__main__":
    main()

