#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

from hawc import hawcnest, data_structures
from hawc.hawcnest import HAWCUnits as HAWCUnits
from hawc.data_structures import *

from hawc import detector_service as detector_service

from HAWCNest import HAWCNest

cm = HAWCUnits.cm
meter = HAWCUnits.meter

import os
import numpy as np
from optparse import OptionParser

scale = 1.5

def get_detector_xycoords(dsname, opts, verbose=False):
    """ Get the x-y coordinates of all tanks and channels in a detector.

        @param dsname: string name of the detector service instance
    """
    # Access registered detector service by name, in the usual AERIE style
    ds = detector_service.GetService(dsname)
    detector = ds.GetDetector(TimeStamp(opts.gpssec))
    channelStatusMap = ds.GetChannelStatusMap(TimeStamp(opts.gpssec))

    # Iterate over channels and print out the tanks and channels in a list
    lastTank = 0
    (tX, tY, tZ) = (0., 0., 0.)

    xCh = []
    yCh = []
    isGoodCh = []
    isBadCh = []

    xT = []
    yT = []

    xCent = detector.get_array_center_x()
    yCent = detector.get_array_center_y()
    zCent = detector.get_array_center_z()
    print xCent,yCent,zCent

    if verbose:
        print "#  GId  ChId  TkId     X       x [cm]      y [cm]      z [cm]"
    for channel in detector.channels():
        # Next tank
        if lastTank != channel.tank_id:
            lastTank = channel.tank_id
            tank = detector.get_tank(lastTank)
            p = tank.position
            (tX, tY, tZ) = (p.x/cm, p.y/cm, p.z/cm)
            xT.append(p.x / meter)
            yT.append(p.y / meter)

            # Print info if verbose flag is on
            if verbose:
                chInfo = "%6d%6d%6d%6d" % (tank.tank_id, -1, -1, 1)
                pInfo = "%12.2f%12.2f%12.2f" % (tX, tY, tZ)
                print "%s%s" % (chInfo, pInfo)

        # Next channel
        p = channel.position
        (cX, cY, cZ) = (p.x/cm, p.y/cm, p.z/cm)
        xCh.append(p.x / meter)
        yCh.append(p.y / meter)
        isGoodCh.append(channelStatusMap.IsGood(channel.channel_id))
        isBadCh.append( not channelStatusMap.CanBeSetGood(channel.channel_id) )

        # Print info if verbose flag is on
        if verbose:
            chInfo = "%6d%6d%6d%6d" % (channel.channel_id, channel.tank_id, \
                                       channel.tank_channel_id, 1)
            pInfo = "%12.2f%12.2f%12.2f" % (cX - tX, cY - tY, cZ - tZ)
            #vInfo = "%12.2f" % (value or -1000.)
            print "%s%s" % (chInfo, pInfo) #, vInfo)

    return xT, yT, xCh, yCh, isGoodCh, isBadCh, xCent, yCent

def calc_xy_range(x, y):
    """ Given a list of xy coordinates, calculate x and y min and max ranges so
        that the detector plot can be made with a square aspect ratio.

        @param x: A list of detector component x-coordinates
        @param y: A list of detector component y-coordinates
    """
    # Let's assume everything is in meters.  Add a 10-meter border
    xMin = min(x) - 10.
    xMax = max(x) + 10.
    dx = abs(xMax - xMin)

    yMin = min(y) - 10.
    yMax = max(y) + 10.
    dy = abs(yMax - yMin)

    # Adjust the range to keep the aspect ratio square
    if dx > dy:
        yMin = yMin - 0.5*(dx - dy)
        yMax = yMax + 0.5*(dx - dy)
    else:
        xMin = xMin - 0.5*(dy - dx)
        xMax = xMax + 0.5*(dy - dx)

    
    return xMin, xMax, yMin, yMax

def draw_detector(xT, yT, xCh, yCh, goodCh, badCh, xCent, yCent, opts):
    """ Draw the detector tanks and channels.

        @param xT: list of tank x-coordinates
        @param yT: list of tank y-coordinates
        @param xCh: list of channel x-coordinates
        @param yCh: list of channel y-coordinates
    """
    # Try to plot the coordinates; catch exceptions for users w/o matplotlib
    try:
        import matplotlib
        #matplotlib.use('Agg')
        import matplotlib.pyplot as plt


        fig = plt.figure(figsize=(scale*6.3, scale*6.3), dpi=100)
        ax = fig.add_subplot(1,1,1)

        # First plot the tanks
        for i in range(0, len(xT)):
            c = plt.Circle((xT[i], yT[i]), radius=3.65,
                           fc="none", ec="#aaaaaa")
            ax.add_patch(c)

        # Then plot the channels
        # good and not bad
        nGoodNotBad = 0
        xxyy = [[x,y] for x,y,g,b in zip(xCh,yCh,goodCh,badCh) if (g is True and b is False)]
        if xxyy:
            xx, yy = zip(*xxyy)
            ax.plot(xx, yy, "p", marker="o", ms=scale*3., mec="#00cc00", mfc="#00cc00")
            nGoodNotBad = len(xx)
        # good and bad
        nGoodBad = 0
        xxyy = [[x,y] for x,y,g,b in zip(xCh,yCh,goodCh,badCh) if (g is True and b is True)]
        if xxyy:
            xx, yy = zip(*xxyy)
            ax.plot(xx, yy, "p", marker="o", ms=scale*3., mec="#0000ff", mfc="#0000ff")
            nGoodBad = len(xx)
        # not good and bad
        nNotGoodBad = 0
        xxyy = [[x,y] for x,y,g,b in zip(xCh,yCh,goodCh,badCh) if (g is False and b is True)]
        if xxyy:
            xx, yy = zip(*xxyy)
            ax.plot(xx, yy, "p", marker="o", ms=scale*3., mec="#cc0000", mfc="#cc0000")
            nNotGoodBad = len(xx)
        # not good and not bad
        nNotGoodNotBad = 0
        xxyy = [[x,y] for x,y,g,b in zip(xCh,yCh,goodCh,badCh) if (g is False and b is False)]
        if xxyy:
            xx, yy = zip(*xxyy)
            ax.plot(xx, yy, "p", marker="o", ms=scale*3., mec="#ff9900", mfc="#ff9900")
            nNotGoodNotBad = len(xx)

        ax.set_xlabel("x [meter]")
        ax.set_ylabel("y [meter]")

        if opts.gridxy:
            ax.xaxis.grid()
            ax.yaxis.grid()

        title = "Channel status for GPSSec = %d.\nGreen = good and not bad (%d). Red = not good and bad (%d).\nBlue = good and bad (%d). Orange = not good and not bad (%d)." %(opts.gpssec,nGoodNotBad,nNotGoodBad,nGoodBad,nNotGoodNotBad)
        ax.set_title(title)

        xMin, xMax, yMin, yMax = calc_xy_range(xCh, yCh)
        xL = np.abs(xMax - xMin)
        yL = np.abs(yMax - yMin)
        if xL > yL:
            yMin -= 0.5*(xL-yL)
            yMax += 0.5*(xL-yL)
        else:
            xMin -= 0.5*(yL-xL)
            xMax += 0.5*(yL-xL)

        print 'Range:', xMin, xMax, yMin, yMax
        #xMin=-67.8634201518
        #xMax=139.121581754
        #yMin=143.443531323
        #yMax=350.428533228
        #print 'Range:', xMin, xMax, yMin, yMax
        plt.plot([xCent],[yCent],"r*")
        plt.xlim([xMin, xMax])
        plt.ylim([yMin, yMax])
        plt.subplots_adjust(left=0.15, right=0.95)

        if opts.output:
            print 'Saving to file', opts.output
            plt.savefig(opts.output)

        if not opts.nodisplay:
            print 'Popup plot'
            plt.show()

    except ImportError, e:
        print "\nSorry, couldn't plot the detector: %s" % e

def main():
    """ Main function: execute the program here.
    """

    # Set up the command-line parser
    usage = "%prog [options]"
    parser = OptionParser(usage)
    parser.add_option("-s", "--gpssec", dest="gpssec", default=2000000000,
                      type="int", help="GPS second to get the detector")
    parser.add_option("-g", "--gridxy", dest="gridxy",
                      action="store_true",
                      help="Draw xy gridlines in the plot")
    parser.add_option("-o", "--output", dest="output", default=None,
                      help="Output plot to image file (e.g., image.png)")
    parser.add_option("-v", "--verbose", dest="verbose",
                      action="store_true",
                      help="Print detector coordinates as they are accessed")
    parser.add_option("--nodisplay", dest="nodisplay",
                      action="store_true",
                      help="No display")
    opts, args = parser.parse_args()
    if len(args) > 0:
        parser.error("Program takes no arguments; only options.")

    # Set up the HAWCNest framework and the detector service
    nest = HAWCNest()

    nest.Service("ConfigDirDetectorService", "detService",
        configDir=os.environ["CONFIG_HAWC"]);

    nest.Configure()
    nest.Finish()
    #get_good_channels("detService", opts)

    # Access pieces of the Detector and try to draw it
    xT, yT, xCh, yCh, goodCh, badCh, xCent, yCent = get_detector_xycoords("detService", opts, verbose=opts.verbose)
    draw_detector(xT, yT, xCh, yCh, goodCh, badCh, xCent, yCent, opts)
    if opts.verbose:
        for g,b in zip(goodCh,badCh):
            print ' -',g,b


if __name__ == "__main__":
    main()

