# grabs max charge from specified calibration file
# and outputs to example.txt
# 
# trig_run002195_00330.xcd is just a dummy in this case.
# In the absence of a specific charge cal, it would be used
# to find the right calibration from config-hawc.

# data files for following calibrations
#
# trig_run000981_00001.xcd --> ChargeCalib_run000980.xcd
# trig_run001220_00001.xcd --> ChargeCalib_run001219.xcd
# trig_run001739_00001.xcd --> ChargeCalib_run001738.xcd
# trig_run001778_00001.xcd --> ChargeCalib_run001777.xcd
# trig_run001855_00001.xcd --> ChargeCalib_run001854.xcd
# trig_run001870_00001.xcd --> ChargeCalib_run001869.xcd
# trig_run001995_00001.xcd --> ChargeCalib_run001994.xcd
# trig_run002036_00001.xcd --> ChargeCalib_run002035.xcd
# trig_run002117_00001.xcd --> ChargeCalib_run002116.xcd
# trig_run002229_00001.xcd --> ChargeCalib_run002228.xcd
# trig_run002304_00001.xcd --> ChargeCalib_run002303.xcd
# trig_run002453_00001.xcd --> ChargeCalib_run002303.xcd (more live PMTs added)
#
# - Josh Wood, April 1 2015
#
files=(trig_run000981_00001.xcd
       trig_run001220_00001.xcd
       trig_run001739_00001.xcd
       trig_run001778_00001.xcd
       trig_run001855_00001.xcd
       trig_run001870_00001.xcd
       trig_run001995_00001.xcd
       trig_run002036_00001.xcd
       trig_run002117_00001.xcd
       trig_run002229_00001.xcd
       trig_run002304_00001.xcd
       trig_run002453_00001.xcd)

for file in ${files[@]}; do

  aerie-apps-cal-info --plotCharge \
                    -c $CONFIG_HAWC \
                    --b example \
                    --hiTOT 10000 \
                    --time01 80 \
                    --loTOT 10080 \
                    --input $file \
                    -f  $CONFIG_HAWC/calibrations/ChargeCalibrations/$qcal \
                    --rotate \
                    --output `expr substr $file 1 20`_config-hawc_r24671.txt
done

# get rid of pictures since
# I just want the text files
rm example*.png

