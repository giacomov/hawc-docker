from xml.dom import minidom
import sys
xmldoc = minidom.parse(sys.argv[1])

tanklist = xmldoc.getElementsByTagName('tank') 

for tank in tanklist:
    chanlist = tank.getElementsByTagName("channel")
    id = tank.attributes["id"].value

    x = float(tank.getElementsByTagName("x")[0].firstChild.data)
    y = float(tank.getElementsByTagName("y")[0].firstChild.data)
    z = float(tank.getElementsByTagName("z")[0].firstChild.data)

    name = tank.getElementsByTagName("name")[0].firstChild.data


    print name.rstrip().lstrip(),id,x,y,z

#print len(tanklist)




