# pmt locations
python parse-pmt-layout.py HAWCRealSurvey-oldnorth.xml > ../pmt-layout-01
python parse-pmt-layout.py HAWCRealSurvey-newnorth.xml > ../pmt-layout-02

# tank locations
python parse-tank-layout.py HAWCRealSurvey-oldnorth.xml > ../tank-layout-01
python parse-tank-layout.py HAWCRealSurvey-newnorth.xml > ../tank-layout-02
