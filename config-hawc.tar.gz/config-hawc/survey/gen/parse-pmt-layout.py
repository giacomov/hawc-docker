from xml.dom import minidom
import sys

xmldoc = minidom.parse(sys.argv[1])

tanklist = xmldoc.getElementsByTagName('tank') 

for tank in tanklist:
    chanlist = tank.getElementsByTagName("channel")

    x = float(tank.getElementsByTagName("x")[0].firstChild.data)
    y = float(tank.getElementsByTagName("y")[0].firstChild.data)
    z = float(tank.getElementsByTagName("z")[0].firstChild.data)


    for chan in chanlist:
        name = chan.getElementsByTagName("name")[0].firstChild.data
	tcid = chan.getElementsByTagName("number")[0].firstChild.data
        dx = float(chan.getElementsByTagName("x")[0].firstChild.data)
        dy = float(chan.getElementsByTagName("y")[0].firstChild.data)
        dz = float(chan.getElementsByTagName("z")[0].firstChild.data)

        type = None
        if name.rstrip().endswith("C"):
            type = 2
        else:
            type = 1 

        print name.rstrip().lstrip(),name.rstrip().lstrip()[:-1],type,tcid,x+dx,y+dy,z+dz






