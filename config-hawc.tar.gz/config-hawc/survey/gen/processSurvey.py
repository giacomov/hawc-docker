#!/usr/bin/env python

# This is John Pretz's re-implementation of Jim Braun's program for
# turning Hermes' excel file for the pmt locations into the format we want
# for analysis

# This reads in an ascii text file with the following 9 columns:
#
# Row (E-X) Tank (1-20) PMT (A-D) X_Engineering (m) Y_Engineering (m) 
# X_Survey (m) Y_Survey (m) Z_Survey (mm) True_Z (mm).  
# These are columns B,C,D,E,F,H,I,J,K of Hermes's spreadsheet.


import sys
from math import cos
from math import sin

# Translation between HAWC coordinate system and origin of grid 14Q
TRANSLATE_XP = 678000+106.3
TRANSLATE_YP = 2101000-133.7

TRANSLATE_X = 0
TRANSLATE_Y = 100

# Rotation between HAWC coordinate system axes and true north
# Measurements:
#
# Hermes, Oct 2013: -15.54 +/- 0.01 using Polaris
# Pat Harding, Nov. 2013: 15.48 +/ 0.06 using GPS
#
RP = -15.54
RPR = RP * 3.14159265359 / 180.

# Default Z point relation for unsurveyed tanks
# and default height of PMTs above Z point
ZFIT_OFFSET_M = 3.40497882e-01
ZFIT_X_DEP = -5.68659674e-05
ZFIT_Y_DEP = -1.00882876e-0;
DEFAULT_Z_ABD_M = 0.313
DEFAULT_Z_C_M = 0.339

TANKID = 1
CHANNELID = 1

infileName = sys.argv[1]
infile = open(infileName)

outfilePMTs = open("pmt-layout.txt","w")
outfileTanks = open("tank-layout.txt","w")

tankNumbersFile = open("tank-numbers.txt")
tankNumbers = {}
for line in tankNumbersFile:
    if not line.startswith("#"):
        tokens = line.split()
        tankNumbers[tokens[0]] = int(tokens[1])

for line in infile:
    tokens = line.split()
    if line.startswith("#"):
        pass
    else:
        if len(tokens) != 9:
            print "amg bad data"
            sys.exit(1)
    pmtName = "%s%s%s"%(tokens[0],tokens[1],tokens[2])
    tankName = "%s%s"%(tokens[0],tokens[1])

    X = float(tokens[5]) - TRANSLATE_X
    Y = float(tokens[6]) - TRANSLATE_Y
    Z_SURVEY = float(tokens[7])/1000.
    Z = float(tokens[8])/1000.

    XP = (X * cos(RPR) + Y * sin(RPR)) * 100.
    YP = (-1.* X * sin(RPR) + Y * cos(RPR))*100
    ZP = Z * 100;

    pmtType = 1
    if tokens[2] == "C":
        pmtType = 2

    pmtLocInTank = None
    if tokens[2] == "A":
        pmtLocInTank = 1
    if tokens[2] == "B":
        pmtLocInTank = 2
    if tokens[2] == "C":
        pmtLocInTank = 3
    if tokens[2] == "D":
        pmtLocInTank = 4

    print >>outfilePMTs,pmtName,tankName,pmtType,pmtLocInTank,XP,YP,ZP

    if pmtType == 2:
        print >>outfileTanks,tankName,tankNumbers[tankName],XP,YP,ZP

#   # Apply rotation, convert length to centimeters
#   $XP = ($X * cos($RPR) + $Y * sin($RPR))*100;
#   $YP = (-1.* $X * sin($RPR) + $Y * cos($RPR))*100;
#   $ZP = $Z * 100;

#   $T = 1;
#   $NUM = 1;
#   if ($L eq "A") {
#     $NUM = 1;
#   }
#   if ($L eq "B") {
#     $NUM = 2;
#   }
#   if ($L eq "C") {
#     $T = 2;
#     $NUM = 3;
#     # Set tank Z to Z coordinate of center PMT; convert to cm
#     $TANK_Z = $Z_SURVEY * 100;
#   }
#   if ($L eq "D") {
#     $NUM = 4;
#   }

#   $XALL[$NUM] = $XP;
#   $YALL[$NUM] = $YP;
#   $ZALL[$NUM] = $ZP;
#   $TYPE[$NUM] = $T;
#   $PMTID[$NUM] = $PID;

#   if ($L eq "D") {

#     print "    <tank id=\"$TANKID\">\n";
#     $TANKID++;
#     print "      <name> $TN </name>\n";
#     print "      <type> 1 </type>\n";
#     print "      <position>\n";
#     printf( "        <x unit=\"cm\"> %.2f </x>\n", $XALL[3]);
#     printf( "        <y unit=\"cm\"> %.2f </y>\n", $YALL[3]);
#     printf( "        <z unit=\"cm\"> %.2f </z>\n", $TANK_Z);
#     print "      </position>\n";
#     print "      <channels>\n";
#     for ($I = 1; $I < 5; $I++) {
#       print "        <channel id=\"$CHANNELID\">\n";
#       $CHANNELID++;
#       print "          <name> $PMTID[$I] </name>\n";
#       print "          <number> $I </number>\n";
#       print "          <type> $TYPE[$I] </type>\n";
#       print "          <position>\n";
#       $XC = $XALL[$I] - $XALL[3];
#       $YC = $YALL[$I] - $YALL[3];
#       $ZC = $ZALL[$I] - $TANK_Z;
#       printf( "            <x unit=\"cm\"> %.2f </x>\n", $XC);
#       printf( "            <y unit=\"cm\"> %.2f </y>\n", $YC);
#       printf( "            <z unit=\"cm\"> %.2f </z>\n", $ZC);
#       print "          </position>\n";
#       print "        </channel>\n";
#     }
#     print "      </channels>\n";
#     print "    </tank>\n";
#   }
# }

# print "  </layout>\n";
# print "</detector>\n";


