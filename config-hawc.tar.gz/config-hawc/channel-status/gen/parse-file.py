#!/usr/bin/env python

import glob
from xml.dom import minidom
import sys
import os
from optparse import OptionParser

usage = "usage: %prog [options] file"
parser = OptionParser(usage)
opts,args = parser.parse_args()

try:
  infile = str(args[0])
except:
  raise Exception,"Need an XML file"

dirname = os.path.dirname(os.path.abspath(__file__))

infiles = [infile]

revID = "02"
revFileName = "%s/../good-channels-revision-%s" % (dirname,revID)
revDirName = "good-channels-%s" % revID

lastGoodPMTs = []

goodChannelsFile = []

for file in infiles:
    print file

    xmldoc = minidom.parse(file)

    begin = xmldoc.getElementsByTagName("begin")
    if not begin:
        print "abnormal file without good channel list.. will ignore"
        print file
        continue
    begin = begin[0].firstChild.data
    begin = begin.rstrip().lstrip()
    print begin

    pmts = xmldoc.getElementsByTagName("status")

    goodPmts = []

    for pmt in pmts:
        pmtName = pmt.attributes["channelName"].value
        goodPmts.append(pmtName)

    if goodPmts != lastGoodPMTs:

        outfile = open("%s/../%s/%s"%(dirname,revDirName,begin),'w')
        for pmt in goodPmts:
            print >>outfile,pmt
        outfile.close()

        goodChannelsFile.append([begin,"channel-status/%s/%s"%(revDirName,begin)])

        lastGoodPMTs = goodPmts

# combine the lists
if(os.path.exists(revFileName)):
  readFile = open(revFileName,"r")
  for line in readFile:
    time,fname = line.split()
    goodChannelsFile.append([time,fname])
  readFile.close()

# sort the times
goodChannelsFile.sort()

goodChannelsSignpostFile = open("%s/../good-channels-revision-02" % dirname,"w")
for time,fname in goodChannelsFile:
  goodChannelsSignpostFile.write("%s %s\n" % (time,fname))
goodChannelsSignpostFile.close()

