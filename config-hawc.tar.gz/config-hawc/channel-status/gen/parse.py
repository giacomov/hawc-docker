#!/usr/bin/env python

import glob
from xml.dom import minidom
import sys
import os

#infiles = glob.glob("calib/2013/*/run*/good_channels.xml")
#infiles = glob.glob("/lustre/scratch/aimran/good_chann_list/xmls/good_channels_*.xml")
#infiles = glob.glob("/data/scratch/bpatricelli/HAWC/Mrk421/ReReco/good_channel/HAWCConfig_newRuns/xml5/good_channels_*.xml")
#infiles = glob.glob("/global/user/home/hawc/calibration/config-hawc/channel-status/gen/*.xml")
#infiles = glob.glob("/home/tweisgarber/projects/good-channels/xml4164-4251/good_channels_*.xml")
infiles = glob.glob("/home/tweisgarber/projects/good-channels/xml4339-4429/good_channels_*.xml")
#infiles = glob.glob("good_channels_*.xml")
infiles.sort()
revID = "02"
revFileName = "../good-channels-revision-%s" % revID
revDirName = "good-channels-%s" % revID

lastGoodPMTs = []

goodChannelsFile = []

for file in infiles:
    print file

    xmldoc = minidom.parse(file)

    begin = xmldoc.getElementsByTagName("begin")
    if not begin:
        print "abnormal file without good channel list.. will ignore"
        print file
        continue
    begin = begin[0].firstChild.data
    begin = begin.rstrip().lstrip()
    print begin

    pmts = xmldoc.getElementsByTagName("status")

    goodPmts = []

    for pmt in pmts:
        pmtName = pmt.attributes["channelName"].value
        goodPmts.append(pmtName)

    if goodPmts != lastGoodPMTs:

        outfile = open("../%s/%s"%(revDirName,begin),'w')
        for pmt in goodPmts:
            print >>outfile,pmt
        outfile.close()

        goodChannelsFile.append([begin,"channel-status/%s/%s"%(revDirName,begin)])

        lastGoodPMTs = goodPmts

# combine the lists
if(os.path.exists(revFileName)):
  readFile = open(revFileName,"r")
  for line in readFile:
    time,fname = line.split()
    goodChannelsFile.append([time,fname])
  readFile.close()

# sort the times
goodChannelsFile.sort()

goodChannelsSignpostFile = open("../good-channels-revision-02","w")
for time,fname in goodChannelsFile:
  goodChannelsSignpostFile.write("%s %s\n" % (time,fname))
goodChannelsSignpostFile.close()

# tanklist = xmldoc.getElementsByTagName('tank')

# for tank in tanklist:


#     x = float(tank.getElementsByTagName("x")[0].firstChild.data)
#     y = float(tank.getElementsByTagName("y")[0].firstChild.data)
#     z = float(tank.getElementsByTagName("z")[0].firstChild.data)


#     for chan in chanlist:
#         name = chan.getElementsByTagName("name")[0].firstChild.data
# 	tcid = chan.getElementsByTagName("number")[0].firstChild.data
#         dx = float(chan.getElementsByTagName("x")[0].firstChild.data)
#         dy = float(chan.getElementsByTagName("y")[0].firstChild.data)
#         dz = float(chan.getElementsByTagName("z")[0].firstChild.data)

#         type = None
#         if name.rstrip().endswith("C"):
#             type = 2
#         else:
#             type = 1

#         print name.rstrip().lstrip(),name.rstrip().lstrip()[:-1],type,tcid,x+dx,y+dy,z+dz






