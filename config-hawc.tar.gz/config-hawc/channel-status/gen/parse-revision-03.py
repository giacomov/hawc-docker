#!/usr/bin/env python

import glob
import sys
import os
import subprocess
import re
from optparse import OptionParser

usage = "usage: %prog [options] directory"
parser = OptionParser(usage)
parser.add_option("-d","--days",dest = "days",type = int,default = 10,help = "Maximum number of days to include in one file")
opts,args = parser.parse_args()

# find time stamp items in a string
def find_ts_items(item):
  items = None
  search_result = re.search("([0-9]+)-([0-9]+)-([0-9]+)T([0-9]+):([0-9]+):([0-9]+)Z",item)
  if(search_result): items = search_result.groups()
  if(items):
    try:
      items = map(int,items)
      if(len(items) != 6): items = None
    except:
      items = None
  if(items is None): return None
  return [x for x in items]

# make a timestamp
def make_timestamp(items):
  return "%04d-%02d-%02dT%02d:%02d:%02dZ" % (items[0],items[1],items[2],items[3],items[4],items[5])

# read PMTs from the file
def read_pmts(file):
  pmts = []
  infile = open(file,"r")
  for line in infile:
    if(line[0] != "#"): pmts.append(line.rstrip())
  return pmts

# return whether the second ts passes the cut
def ts_passes(ts1,ts2,days):
  if(ts1 > ts2): return False
  items1 = find_ts_items(ts1)
  items2 = find_ts_items(ts2)
  if(items1 is None or items2 is None): return False
  if(items1[0] != items2[0]): return False
  if(items1[1] != items2[1]): return False
  if(items2[2]-items1[2] > days): return False
  return True

# read the file
def read_new_file(file):
  infile = open(file,"r")
  items = find_ts_items(file)
  pmt_lists = {}
  if(items is not None):
    tstart = make_timestamp(items)
    tref = tstart
    pmt_lists[tstart] = []
    for line in infile:
      rline = line.rstrip()
      if(len(rline) > 1):
        remainder = rline[1:]
        if(rline[0] == "="):
          pmt_lists[remainder] = [x for x in pmt_lists[tref]]
          tref = remainder
        elif(rline[0] == "+"):
          if(remainder not in pmt_lists[tref]): pmt_lists[tref].append(remainder)
        elif(rline[0] == "-"):
          if(remainder in pmt_lists[tref]): pmt_lists[tref].remove(remainder)
  infile.close()
  return pmt_lists

# start the code here

# get the directory
try: dir = args[0]
except: raise Exception,"Need a directory"

# list all files in the directory
infiles = glob.glob(os.path.join(dir,"*"))
dirname = os.path.dirname(os.path.abspath(__file__))

# set up revision information
rev_id = "03"
rev_file_name = "live-channels-revision-%s" % rev_id
rev_dir_name = "live-channels-%s" % rev_id
rev_dir_rel = os.path.join("channel-status",rev_dir_name)
rev_file = os.path.join(dirname,"..",rev_file_name)
rev_dir = os.path.join(dirname,"..",rev_dir_name)

# make a dictionary of time stamp to existing file
file_dict = {}
for file in os.listdir(rev_dir):
  fullpath = os.path.join(rev_dir,os.path.basename(file))
  relpath = os.path.join(rev_dir_rel,os.path.basename(file))
  items = find_ts_items(file)
  if(items is not None):
    ts = make_timestamp(items)
    file_dict[ts] = [fullpath,relpath]
sorted_keys = sorted(file_dict)

infiles.sort()
print "Looking at files in %s and putting results in %s" % (dir,rev_dir)
subprocess.call("mkdir -p %s" % rev_dir,shell = True)

# deal with files that can fit into existing files
latefiles = []
last_read = ""
pmt_lists = {}
if(len(sorted_keys) > 0):
  for file in infiles:
    items = find_ts_items(file)
    if(items):
      ts = make_timestamp(items)
      index = -1
      for i in range(0,len(sorted_keys)-1):
        if(sorted_keys[i] <= ts and sorted_keys[i+1] > ts and index == -1): index = i
      if(index == -1 and ts_passes(sorted_keys[len(sorted_keys)-1],ts,opts.days)): index = len(sorted_keys)-1
      if(index != -1 and not ts_passes(sorted_keys[index],ts,opts.days)): index = -1
      if(index == -1):
        latefiles.append(file)
      else:
        key_file = file_dict[sorted_keys[index]][0]
        if(key_file not in pmt_lists):
          pmt_lists[key_file] = [read_new_file(key_file),[]]
          pmt_lists[key_file][1] = sorted(pmt_lists[key_file][0])
        pmt_index = -1
        for i in range(0,len(pmt_lists[key_file][1])-1):
          if(pmt_lists[key_file][1][i] <= ts and pmt_lists[key_file][1][i+1] > ts and pmt_index == -1): pmt_index = i
        if(pmt_index == -1): pmt_index = len(pmt_lists[key_file][1])-1
        new_pmts = read_pmts(file)
        if(ts == pmt_lists[key_file][1][pmt_index]):
          pmt_lists[key_file][0][ts] = [x for x in new_pmts]
        else:
          pmt_lists[key_file][0][ts] = [x for x in new_pmts]
          pmt_lists[key_file][1] = sorted(pmt_lists[key_file][0])
else:
  latefiles = [x for x in infiles]

# update the files with the new information
for key_file in pmt_lists:
  print "Rewriting %s" % key_file
  last_pmts = []
  outfile = open(key_file,"w")
  first = True
  for ts in pmt_lists[key_file][1]:
    if(first):
      for pmt in sorted(pmt_lists[key_file][0][ts]): outfile.write("+%s\n" % pmt)
      last_pmts = [x for x in pmt_lists[key_file][0][ts]]
    else:
      dropouts = [x for x in last_pmts if x not in pmt_lists[key_file][0][ts]]
      dropins = [x for x in pmt_lists[key_file][0][ts] if x not in last_pmts]
      if(len(dropouts)+len(dropins) > 0):
        outfile.write("=%s\n" % ts)
        for pmt in sorted(dropins): outfile.write("+%s\n" % pmt)
        for pmt in sorted(dropouts): outfile.write("-%s\n" % pmt)
      last_pmts = [x for x in pmt_lists[key_file][0][ts]]
    first = False
  outfile.close()

# process the late files
live_pmts = []
target_file = None
ftarget = None
last_items = []
last_ts = None
if(len(latefiles) > 0):
  last_items = find_ts_items(latefiles[0])
  last_ts = make_timestamp(last_items)
for file in latefiles:
  items = find_ts_items(file)
  if(items):
    ts = make_timestamp(items)
    new_pmts = read_pmts(file)
    new_pmts.sort()
    if(not target_file or not ts_passes(last_ts,ts,opts.days)):
      target_file = os.path.join(rev_dir,os.path.basename(file))
      last_items = [x for x in items]
      last_ts = ts
      print "Opening new target file: %s" % target_file
      if(ts in file_dict): raise "Duplicate TS: %s" % ts
      file_dict[ts] = [target_file,os.path.join(rev_dir_rel,os.path.basename(target_file))]
      if(ftarget is not None): ftarget.close()
      ftarget = open(target_file,"w")
      for pmt in sorted(new_pmts): ftarget.write("+%s\n" % pmt)
    else:
      dropouts = [x for x in live_pmts if x not in new_pmts]
      dropins = [x for x in new_pmts if x not in live_pmts]
      if(len(dropins)+len(dropouts) > 0):
        ftarget.write("=%s\n" % make_timestamp(items))
        for pmt in sorted(dropins): ftarget.write("+%s\n" % pmt)
        for pmt in sorted(dropouts): ftarget.write("-%s\n" % pmt)
    live_pmts = [x for x in new_pmts]
    live_pmts.sort()
if(ftarget is not None): ftarget.close()

# rewrite the signpost file
frev = open(rev_file,"w")
for ts in sorted(file_dict):
  frev.write("%s %s\n" % (ts,file_dict[ts][1]))
frev.close()

