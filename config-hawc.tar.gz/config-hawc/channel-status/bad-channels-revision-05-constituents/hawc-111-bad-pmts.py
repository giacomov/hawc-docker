def parselist(infileName,column):
  infile = open(infileName)

  PMTs = []

  for line in infile:
    tokens = line.split()
    pmt = tokens[column].rstrip().lstrip()
    PMTs.append(pmt)
  return PMTs

allPMTs = parselist("hawc-111-all-pmts.txt",1)
e12live = parselist("hawc-111-epoch12-live.txt",0)
e3live = parselist("hawc-111-epoch3-live.txt",0)

print len(allPMTs),len(e12live),len(e3live)

exclude_e12 = ["E18B","E18D","K19B","K19D","F19A","L14C","L14B","N17D","O15B"]
exclude_e3 = ["E18B","E18D","K19B","K19D","E18C","F19A","G14D","N17D","O15B","R16A","T12A","U12C","U12D"]

for live,excluded,outfileName in ((e12live,exclude_e12,"../bad-channels-05/2012-01-01T00:00:00Z"),(e3live,exclude_e3,"../bad-channels-05/2014-03-05T17:25:00Z")):
  outfile = open(outfileName,"w")
  for pmt in allPMTs:
    bad = False
    if pmt not in live:
      bad = True
    if pmt in excluded:
      bad = True
    if bad:
      print >>outfile,pmt

#    if bad:
#      print pmt,"BAD"
#    else:
#      print pmt,"NOT BAD"
  outfile.close()

