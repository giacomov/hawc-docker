import os

def parseBad(fname):
    badPMTs = []
    if os.path.exists(fname):
        badChannelsFile = open(fname)
        for line in badChannelsFile:
            if not line.startswith("#"):
                tokens = line.split()
                if len(tokens) > 0:
                    badPMT = tokens[0].rstrip().lstrip()
                    badPMTs.append(badPMT)
    else:
        print fname,"doesn't exist"
    return badPMTs

chargeCalibrationEpochs = [("cal0980_run001000_subrun00001","2012-01-01T00:00:00Z"), 
                           ("cal1219_run001500_subrun00001","2014-03-05T17:25:00Z"), 
                           ("cal1738_run001710_subrun00001","2014-07-09T20:45:00Z"), 
                           ("cal1777_run001805_subrun00001","2014-08-08T15:30:01Z"), 
                           ("cal1854_run001854_subrun00001","2014-09-11T17:43:29Z"), 
                           ("cal1869_run001869_subrun00001","2014-09-16T20:34:56Z"), 
                           ("cal1994_run001994_subrun00001","2014-10-31T21:10:08Z"), 
                           ("cal2035_run002035_subrun00001","2014-11-03T19:53:12Z"), 
                           ("cal2116_run002118_subrun00001","2014-11-11T16:33:46Z"), 
                           ("cal2116_run002141_subrun00001","2014-12-08T19:17:00Z"), 
                           ("cal2181_run002147_subrun00001","2014-12-10T17:03:24Z"), 
                           ("cal2228_run002228_subrun00001","2015-01-15T22:23:31Z"), 
                           ("cal2303_run002303_subrun00001","2015-02-04T15:49:08Z"), 
                           ("cal2687_run002687_subrun00001","2015-03-13T20:05:00Z"), 
                           ("cal3055_run003103_subrun00001","2015-04-03T20:05:35Z"), 
                           ("cal3767_run003770_subrun00100","2015-06-08T21:20:00Z"), 
                           ("cal4034_run004400_subrun00100","2015-07-15T23:06:00Z"), 
                           ("cal5213_run005200_subrun00100","2016-02-12T18:01:01Z"),
                           ("cal5809_run005721_subrun00001","2016-06-02T09:02:36Z")] 

# slewingBadPMTLists = [("badChannels3055Slewing.txt","2015-04-03T20:05:35Z"),
#                       ("badChannels3767Slewing.txt","2015-06-08T21:20:00Z"),
#                       ("badChannels4034Slewing.txt","2015-07-15T23:06:00Z")]


#SlewCalib_cal002147_frankenstein_jpmod.xcd
#2014-12-10T17:03:24Z"),


slewingBadPMTLists = [("badChannels1219.txt","2014-03-05T17:25:00Z"),
                      ("badChannels1738.txt","2014-07-09T20:45:00Z"),
                      ("badChannels1777.txt","2014-08-08T15:30:01Z"),
                      ("badChannels1854.txt","2014-09-11T17:43:29Z"),
                      ("badChannels1869.txt","2014-09-16T20:34:56Z"),
                      ("badChannels1994.txt","2014-10-31T21:10:08Z"),
                      ("badChannels2035.txt","2014-11-03T19:53:12Z"),
                      ("badChannels2116.txt","2014-11-11T16:33:46Z"),
                      ("badChannels2116.txt","2014-12-08T19:17:00Z"),
                      ("badChannels2116.txt","2014-12-10T17:03:24Z"),
                      ("badChannels2228.txt","2015-01-15T22:23:31Z"),
                      ("badChannels2303.txt","2015-02-04T15:49:08Z"),
                      ("badChannels2687.txt","2015-03-13T20:05:00Z"),
                      ("badChannels3055.txt","2015-04-03T20:05:35Z"),
                      ("badChannels3767.txt","2015-06-08T21:20:00Z"),
                      ("badChannels4034.txt","2015-07-15T23:06:00Z"),
                      ("badChannels5213.txt","2016-02-12T18:01:01Z"),
                      ("badChannels5809.txt","2016-06-02T09:02:36Z")]

#

timingBadPMTLists = [("timingbadchannels1219.txt","2014-03-05T17:25:00Z"),
                     ("timingbadchannels1738.txt","2014-07-09T20:45:00Z"),
                     ("timingbadchannels1777.txt","2014-08-08T15:30:01Z"),
                     ("timingbadchannels1854.txt","2014-09-11T17:43:29Z"),
                     ("timingbadchannels1869.txt","2014-09-16T20:34:56Z"),
                     ("timingbadchannels1994.txt","2014-10-31T21:10:08Z"),
                     ("timingbadchannels2035.txt","2014-11-03T19:53:12Z"),
                     ("timingbadchannels2116.txt","2014-11-11T16:33:46Z"),
                     ("timingbadchannels2116.txt","2014-12-08T19:17:00Z"),
                     ("timingbadchannels2116.txt","2014-12-10T17:03:24Z"),
                     ("timingbadchannels2228.txt","2015-01-15T22:23:31Z"),
                     ("timingbadchannels2303.txt","2015-02-04T15:49:08Z"),
                     ("timingbadchannels2687.txt","2015-03-13T20:05:00Z"),
                     ("timingbadchannels3055.txt","2015-04-03T20:05:35Z"),
                     ("timingbadchannels3767.txt","2015-06-08T21:20:00Z"),
                     ("timingbadchannels4034.txt","2015-07-15T23:06:00Z"),
                     ("timingbadchannels5213.txt","2016-02-12T18:01:01Z"),
                     ("timingbadchannels5809.txt","2016-06-02T09:02:36Z")]

efficiencyBadPMTLists = [("run001219.txt","2014-03-05T17:25:00Z"),
                         ("run001738.txt","2014-07-09T20:45:00Z"),
                         ("run001777.txt","2014-08-08T15:30:01Z"),
                         ("run001854.txt","2014-09-11T17:43:29Z"),
                         ("run001869.txt","2014-09-16T20:34:56Z"),
                         ("run001994.txt","2014-10-31T21:10:08Z"),
                         ("run002035.txt","2014-11-03T19:53:12Z"),
                         ("run002116.txt","2014-11-11T16:33:46Z"),
                         ("run002228.txt","2015-01-15T22:23:31Z"),
                         ("run002303.txt","2015-02-04T15:49:08Z"),
                         ("run002687.txt","2015-03-13T20:05:00Z"),
                         ("run003055.txt","2015-04-03T20:05:35Z"),
                         ("run003767.txt","2015-06-08T21:20:00Z"),
                         ("run004034.txt","2015-07-15T23:06:00Z"),
                         ("run005213.txt","2016-02-12T18:01:01Z"),
                         ("run005809.txt","2016-06-02T09:02:36Z"),]


def getBadSlewing(t):
    for fname,ftime in slewingBadPMTLists:
        if ftime == t:
            infile = "slewing-autocheck/%s"%(fname)
            return parseBad(infile)

    return []

def getBadChargeCalibration(t):
    for fname,ftime in chargeCalibrationEpochs:
        if ftime == t:
            infile = "charge-autocheck/bad_channels_%s.txt"%(chargeAutocheckTag)
            badPMTs = parseBad(infile)
            infile = "charge-autocheck/empty_channels_%s.txt"%(chargeAutocheckTag)
            badPMTs = badPMTs + parseBad(infile)
            return badPMTs
    return []

def getBadTiming(t):
    for fname,ftime in timingBadPMTLists:
        if ftime == t:
            infile = "timing-check/%s"%(fname)
            badPMTs = parseBad(infile)
            return badPMTs
    return []

def getBadEfficiency(t):
    for fname,ftime in efficiencyBadPMTLists:
        if ftime == t:
            infile = "relative-efficiency-check/%s"%(fname)
            badPMTs = parseBad(infile)
            return badPMTs
    return []


badPMTIndexFile = open("../bad-channels-revision-05","w")
for chargeAutocheckTag,starttime in chargeCalibrationEpochs:
    badFileName = "bad-channels-05/%s"%(starttime)
    print >>badPMTIndexFile,starttime,"channel-status/%s"%(badFileName)

badPMTLists = {}
for chargeAutocheckTag,starttime in [chargeCalibrationEpochs[len(chargeCalibrationEpochs)-1]]:
    badPMTs = []
    badPMTsSlewing = getBadSlewing(starttime)
    print len(badPMTsSlewing),"Bad in Slewing Check"

    badPMTsCharge = getBadChargeCalibration(starttime)
    print len(badPMTsCharge),"Bad in Charge Autocheck"

    badPMTsTiming = getBadTiming(starttime)
    print len(badPMTsTiming),"Bad in Timing"

    badPMTsEfficiency = getBadEfficiency(starttime)

    badPMTs = badPMTsCharge + badPMTsSlewing + badPMTsTiming + badPMTsEfficiency

    badPMTs = list(set(badPMTs))
    badPMTs.sort()

    badFileName = "bad-channels-05/%s"%(starttime)
    outfile = open("../%s"%(badFileName),"w")
    print >> outfile ,"# This file is AUTOMATICALLY generated. Do not edit."
    print >> outfile ,"# Instead, edit the generation script"
    for pmt in badPMTs:
        print >> outfile,pmt
    outfile.close()
    print chargeAutocheckTag,starttime,len(badPMTs)



