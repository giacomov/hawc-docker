
import subprocess
import sys
import glob
import os

from hawc import hawcnest
from hawc.data_structures import TimeStamp
from hawc.data_structures import UTCDateTime

import mysql.connector

srcServer = {
    'user':'hawc_user',
    'password':'orizaba!',
    'host':'hawcmon.umd.edu',
    'database':'QMDB'
}

cnx = mysql.connector.connect(**srcServer)
cursor = cnx.cursor()

def getValidTime(calibFile):
  proc = subprocess.Popen(["xcdf-utility","info",calibFile],stdout=subprocess.PIPE)
  startTime = None
  for line in proc.stdout:
    utcstart = line.find("UTC")
    if utcstart > 0:
      startTime = line[utcstart+5:utcstart+25]
  if startTime == None:
    print calibFile,"HAS NO START TIME"
  return startTime

def getBadPMTRevision(config_hawc):
    infile = open(config_hawc+"/channel-status/bad-channels-revision")
    revisionNumber = None
    for line in infile:
        if line.startswith("#"):
            continue
        else:
            if revisionNumber == None:
                revisionNumber = int(line.split()[0])
    return revisionNumber

allCalibrationEpochs = {}

chargeCalibrations = {}
chargeFiles = glob.glob(os.path.expandvars("$CONFIG_HAWC/calibrations/ChargeCalibrations/ChargeCalib_*.xcd"))
for chargeFile in chargeFiles:
  chargeCalibrations[getValidTime(chargeFile)] = os.path.basename(chargeFile)
  startTime = getValidTime(chargeFile)
  if startTime != None:
    allCalibrationEpochs[startTime] = 1

slewCalibrations = {}
slewFiles = glob.glob(os.path.expandvars("$CONFIG_HAWC/calibrations/SlewingCalibrations/Slew*.xcd"))
for slewFile in slewFiles:
  slewCalibrations[getValidTime(slewFile)] = os.path.basename(slewFile)
  startTime = getValidTime(slewFile)
  if startTime != None:
    allCalibrationEpochs[startTime] = 1

tresCalibrations = {}
tresFiles = glob.glob(os.path.expandvars("$CONFIG_HAWC/calibrations/TimeResidualCalibrations/TimeResidual_*.xcd"))
for tresFile in tresFiles:
  tresCalibrations[getValidTime(tresFile)] = os.path.basename(tresFile)
  startTime = getValidTime(tresFile)
  if startTime != None:
    allCalibrationEpochs[startTime] = 1

badPMTLists = {}
badPMTRevisionFile = getBadPMTRevision(os.path.expandvars("$CONFIG_HAWC"))
print badPMTRevisionFile
badPMTListFile = open(os.path.expandvars("$CONFIG_HAWC/channel-status/bad-channels-revision-05"))
for line in badPMTListFile:
  tokens = line.split()
  time = tokens[0].rstrip().lstrip()
  fname = tokens[1].rstrip().lstrip()
  badPMTLists[time]=fname
  allCalibrationEpochs[time] = 1


print len(chargeCalibrations),"Charge Calibrations Found"
print len(slewCalibrations),"Slewing Calibrations Found"
print len(tresCalibrations),"Time Residual Calibrations Found"
print len(allCalibrationEpochs),"Total Calibration Epochs"

calibrationEpochs = allCalibrationEpochs.keys()
calibrationEpochs.sort()

for ce in calibrationEpochs:
  print "----------"
  utcdatetime = UTCDateTime(ce)
  print utcdatetime.timestamp.second,
  query="select Run_number,SubRun_number from hawconline where GPSTimeStart_sec>=%d ORDER BY GPSTimeStart_sec LIMIT 1"%(utcdatetime.timestamp.second)
  cursor.execute(query)
  run = None
  subrun = None
  for line in cursor:
    run,subrun = line

  print "(%d,%d)"%(run,subrun),ce
  if chargeCalibrations.has_key(ce):
    print "charge ",chargeCalibrations[ce]
  if slewCalibrations.has_key(ce):
    print "slew ",slewCalibrations[ce]
  if tresCalibrations.has_key(ce):
    print "tres ",tresCalibrations[ce]
  if badPMTLists.has_key(ce):
    print "badpmts ",badPMTLists[ce]

print "----------"

